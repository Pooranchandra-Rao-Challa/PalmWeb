import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Table } from 'primeng/table';
import { SecurityService } from 'src/app/demo/service/security.service';

export interface ITableHeader {
  field: string;
  header: string;
  label: string;
}
@Component({
  selector: 'app-vehicle-information',
  templateUrl: './vehicle-information.component.html',
  styles: []
})
export class VehicleInformationComponent implements OnInit {
 
  dialog: boolean = false;
  @ViewChild('filter') filter!: ElementRef;
  vehicleForm!: FormGroup;
  submitLabel!: string;
  screens: string[] = [];
  vehicles: any;

  constructor(private formbuilder: FormBuilder, private securityService: SecurityService) { }

  ngOnInit(): void {
    this.vehicleForm = this.formbuilder.group({
      Id : [''],
      FastagId : new FormControl('', [Validators.required]),
      VehicleNo : new FormControl('', [Validators.required]),
      Address : new FormControl('', [Validators.required]),
      DriverName : new FormControl('', [Validators.required]),
      MobileNumber : new FormControl('', [Validators.required]),
      DriverAddress : new FormControl('', [Validators.required]),
      PickListId: new FormControl('', [Validators.required]),
    });
   this.initVehicles();
  }
  initVehicles() {
    this.securityService.getVehicles().then((data) =>{
      console.log(data)
      this.vehicles = data;
    } );
  }


  headers: ITableHeader[] = [
    { field: 'Id ', header: 'id', label: 'ID' },
    { field: 'FastagId ', header: 'fastTagId', label: 'Fast tag id ' },
    { field: 'VehicleNo ', header: 'VehicleNo', label: 'Vehical No' },
    { field: 'Address ', header: 'address', label: 'Address' },
    { field: 'DriverName ', header: 'driverName', label: 'Driver Name ' },
    { field: 'PhoneNo', header: 'PhoneNo', label: 'PhoneNo' },
    { field: 'DriverAddress ', header: 'driverAddress', label: 'driverAddress' },
    { field: 'PickListId', header: 'PickListId', label: 'PickListId' },
    { field: 'CreatedAt  ', header: 'CreatedAt ', label: 'Created At ' },
    { field: 'CreatedBy ', header: 'CreatedBy ', label: 'Created By ' },
    { field: 'UpdatedAt ', header: 'UpdatedAt', label: 'Updated At' },
    { field: 'UpdatedBy ', header: 'UpdatedBy ', label: 'Updated By ' },

  ];



  showDialog() {
    this.vehicleForm.reset();
    this.dialog = true;
  }
  editVehicle(){
    this.showDialog();
    
    this.submitLabel = "Update Vehicle";
  }
  initVehicle() {
    this.showDialog();
      this.submitLabel = "Add Vehicle";
  }


  clear(table: Table) {
    table.clear();
    this.filter.nativeElement.value = '';
  }

  onGlobalFilter(table: Table, event: Event) {
    table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
  }

  

  onSubmit() {

  }

}

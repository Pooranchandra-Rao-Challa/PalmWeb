import { Component } from '@angular/core';

@Component({
  selector: 'app-boom-barrier',
  templateUrl: './boom-barrier.component.html',
  styles: []
})
export class BoomBarrierComponent {

}

import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Table } from 'primeng/table';
import { SecurityService } from 'src/app/demo/service/security.service';

export interface ITableHeader {
  field: string;
  header: string;
  label: string;
}

@Component({
  selector: 'app-vehicles-in-out-info',
  templateUrl: './vehicles-in-out-info.component.html',
  styles: []
})

export class VehiclesInOutInfoComponent {
  dialog: boolean = false;
  @ViewChild('filter') filter!: ElementRef;
  vehicleForm!: FormGroup;
  submitLabel!: string;
  screens: string[] = [];
  vehicles: any;

  constructor(private formbuilder: FormBuilder, private securityService: SecurityService) { }

  ngOnInit(): void {
    this.vehicleForm = this.formbuilder.group({
      Id : [''],
      FastagId : new FormControl('', [Validators.required]),
      barrierID: new FormControl('', [Validators.required]),
      date: new FormControl('', [Validators.required]),
      materialWeight: new FormControl('', [Validators.required]),
      carryerWeight: new FormControl('', [Validators.required]),
      netWeight: new FormControl('', [Validators.required]),
      tareWeight: new FormControl('', [Validators.required]),
      fuelQuantity: new FormControl('', [Validators.required]),
    });
   this.initVehicles();
  }
  initVehicles() {
    this.securityService.getVehicleInOutInfo().then((data) =>{
      console.log(data)
      this.vehicles = data;
    } );
  }


  headers: ITableHeader[] = [
    { field: 'Id ', header: 'ID', label: 'ID' },
    { field: 'FastagId ', header: 'fasttagID', label: 'Fast tag id ' },
    { field: 'barrierID', header: 'barrierID', label: 'Barrier ID' },
    { field: 'date', header: 'date', label: 'Date' },
    { field: 'materialWeight', header: 'materialWeight', label: 'Weight of the Material ' },
    { field: 'carryerWeight', header: 'carryerWeight', label: 'Carryer Weight' },
    { field: 'netWeight', header: 'netWeight', label: 'Net Weight' },
    { field: 'tareWeight', header: 'tareWeight', label: 'Tare Weight' },
    { field: 'fuelQuantity', header: 'fuelQuantity', label: 'Fuel Quantity' },
  ];



  showDialog() {
    this.vehicleForm.reset();
    this.dialog = true;
  }
  editVehicle(){
    this.showDialog();
    
    this.submitLabel = "Update Vehicle ";
  }
  initVehicle() {
    this.showDialog();
      this.submitLabel = "Add Vehicle";
  }


  clear(table: Table) {
    table.clear();
    this.filter.nativeElement.value = '';
  }

  onGlobalFilter(table: Table, event: Event) {
    table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
  }

  

  onSubmit() {

  }
}
